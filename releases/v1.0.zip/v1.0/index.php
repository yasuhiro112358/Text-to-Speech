<?php
// ==== Data ====
$words = [
    ['id' => '1', 'word' => 'algorithm', 'ipa' => 'ˈælɡəˌrɪðəm', 'sentence' => 'The algorithm sorts the data efficiently.'],
    ['id' => '2', 'word' => 'function', 'ipa' => 'ˈfʌŋkʃən', 'sentence' => 'This function returns the sum of two numbers.'],
    ['id' => '3', 'word' => 'variable', 'ipa' => 'ˈvɛəriəbl', 'sentence' => 'You need to declare the variable first.'],
    ['id' => '4', 'word' => 'database', 'ipa' => 'ˈdeɪtəˌbeɪs', 'sentence' => 'The data is stored in a relational database.'],
    ['id' => '5', 'word' => 'syntax', 'ipa' => 'ˈsɪntæks', 'sentence' => 'Make sure your syntax is correct.'],
    ['id' => '6', 'word' => 'compile', 'ipa' => 'kəmˈpaɪl', 'sentence' => 'You need to compile the code before running it.'],
    ['id' => '7', 'word' => 'debug', 'ipa' => 'ˌdiːˈbʌɡ', 'sentence' => 'I spent hours trying to debug the program.'],
    ['id' => '8', 'word' => 'server', 'ipa' => 'ˈsɜːrvər', 'sentence' => 'The server is down for maintenance.'],
    ['id' => '9', 'word' => 'client', 'ipa' => 'ˈklaɪənt', 'sentence' => 'The client sent a request to the server.'],
    ['id' => '10', 'word' => 'framework', 'ipa' => 'ˈfreɪmˌwɜrk', 'sentence' => 'We are using a new JavaScript framework.'],
    ['id' => '11', 'word' => 'API', 'ipa' => 'ˌeɪpiˈaɪ', 'sentence' => 'You can access the data through the API.'],
    ['id' => '12', 'word' => 'object', 'ipa' => 'ˈɒbdʒɪkt', 'sentence' => 'An object in JavaScript can have properties and methods.'],
    ['id' => '13', 'word' => 'class', 'ipa' => 'klæs', 'sentence' => 'The class defines the blueprint for objects.'],
    ['id' => '14', 'word' => 'inheritance', 'ipa' => 'ɪnˈhɛrɪtəns', 'sentence' => 'Inheritance allows a class to use methods from another class.'],
    ['id' => '15', 'word' => 'interface', 'ipa' => 'ˈɪntərˌfeɪs', 'sentence' => 'The user interface is very intuitive.'],
    ['id' => '16', 'word' => 'module', 'ipa' => 'ˈmɒdʒuːl', 'sentence' => 'Each module in the system has a specific function.'],
    ['id' => '17', 'word' => 'library', 'ipa' => 'ˈlaɪˌbrɛri', 'sentence' => 'This library provides a lot of useful functions.'],
    ['id' => '18', 'word' => 'script', 'ipa' => 'skrɪpt', 'sentence' => 'Run the script to automate the process.'],
    ['id' => '19', 'word' => 'loop', 'ipa' => 'luːp', 'sentence' => 'The loop iterates over each element in the array.'],
    ['id' => '20', 'word' => 'array', 'ipa' => 'əˈreɪ', 'sentence' => 'An array can hold multiple values.'],
    ['id' => '21', 'word' => 'binary', 'ipa' => 'ˈbaɪˌnɛri', 'sentence' => 'Computers use binary code to process data.'],
    ['id' => '22', 'word' => 'encryption', 'ipa' => 'ɪnˈkrɪpʃən', 'sentence' => 'Encryption is important for data security.'],
    ['id' => '23', 'word' => 'protocol', 'ipa' => 'ˈproʊtəˌkɔl', 'sentence' => 'HTTP is a protocol used for transmitting data.'],
    ['id' => '24', 'word' => 'firewall', 'ipa' => 'ˈfaɪərˌwɔl', 'sentence' => 'The firewall helps to protect the network.'],
    ['id' => '25', 'word' => 'byte', 'ipa' => 'baɪt', 'sentence' => 'A byte consists of eight bits.'],
    ['id' => '26', 'word' => 'cache', 'ipa' => 'kæʃ', 'sentence' => 'Clearing the cache can resolve some issues.'],
    ['id' => '27', 'word' => 'virtual', 'ipa' => 'ˈvɜrˌtʃuəl', 'sentence' => 'We set up a virtual machine for testing.'],
    ['id' => '28', 'word' => 'repository', 'ipa' => 'rɪˈpɑzɪˌtɔri', 'sentence' => 'The code is stored in a Git repository.'],
    ['id' => '29', 'word' => 'token', 'ipa' => 'ˈtoʊkən', 'sentence' => 'An authentication token is required to access the API.'],
    ['id' => '30', 'word' => 'boolean', 'ipa' => 'ˈbuːliən', 'sentence' => 'A boolean variable can be true or false.'],
];

// ==== Functions ==== 
// Make url to search
function getOLDUrl($search_word)
{
    $url = "https://www.oxfordlearnersdictionaries.com/definition/english/" . $search_word;
    return $url;
}

function getImageSearchUrl($search_word)
{
    $url = "https://www.google.co.jp/search?q=" . $search_word . "&tbm=isch";
    return $url;
}

function getYouGlishUrl($search_word)
{
    $url = "https://youglish.com/pronounce/" . $search_word . "/english";
    return $url;
}

?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>English Words</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Font-awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <div class="container mt-5 mb-5">
        <div class="row">
            <div class="col-12 mx-auto">
                <h1>English Vocas</h1>

                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr class="text-center">
                                <th>ID</th>
                                <th>Word</th>
                                <th>IPA</th>
                                <th>en-US</th>
                                <th>en-GB</th>
                                <th>fr-FR</th>
                                <th>de-DE</th>
                                <th>ja-JP</th>
                                <th>ko-KR</th>
                                <th>zh-Hans-CN</th>
                                <th>Sentence</th>
                                <th>en-US</th>
                                <th>ja-JP</th>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($words as $word) : ?>
                                <tr>
                                    <!-- ID -->
                                    <td class="text-center">
                                        <?= $word['id'] ?>
                                    </td>

                                    <!-- Word -->
                                    <td class="text-center">
                                        <?= $word['word'] ?>
                                    </td>

                                    <!-- IPA -->
                                    <td class="text-center">
                                        <?= $word['ipa'] ?>
                                    </td>

                                    <!-- Read Button for word -->
                                    <td class="text-center">
                                        <button onclick="speakText(this.dataset.text, 'en-US')" data-text="<?= $word['word'] ?>" class="btn p-0 border-0">
                                            <i class="fa-solid fa-circle-play"></i>
                                        </button>
                                    </td>
                                    <td class="text-center">
                                        <button onclick="speakText(this.dataset.text, 'en-GB')" data-text="<?= $word['word'] ?>" class="btn p-0 border-0">
                                            <i class="fa-solid fa-circle-play"></i>
                                        </button>
                                    </td>
                                    <td class="text-center">
                                        <button onclick="speakText(this.dataset.text, 'fr-FR')" data-text="<?= $word['word'] ?>" class="btn p-0 border-0">
                                            <i class="fa-solid fa-circle-play"></i>
                                        </button>
                                    </td>
                                    <td class="text-center">
                                        <button onclick="speakText(this.dataset.text, 'de-DE')" data-text="<?= $word['word'] ?>" class="btn p-0 border-0">
                                            <i class="fa-solid fa-circle-play"></i>
                                        </button>
                                    </td>
                                    <td class="text-center">
                                        <button onclick="speakText(this.dataset.text, 'ja-JP')" data-text="<?= $word['word'] ?>" class="btn p-0 border-0">
                                            <i class="fa-solid fa-circle-play"></i>
                                        </button>
                                    </td>
                                    <td class="text-center">
                                        <button onclick="speakText(this.dataset.text, 'ko-KR')" data-text="<?= $word['word'] ?>" class="btn p-0 border-0">
                                            <i class="fa-solid fa-circle-play"></i>
                                        </button>
                                    </td>
                                    <td class="text-center">
                                        <button onclick="speakText(this.dataset.text, 'zh-Hans-CN')" data-text="<?= $word['word'] ?>" class="btn p-0 border-0">
                                            <i class="fa-solid fa-circle-play"></i>
                                        </button>
                                    </td>

                                    <!-- Sentence -->
                                    <td><?= $word['sentence'] ?></td>

                                    <!-- Read Button for sentence -->
                                    <td class="text-center">
                                        <button onclick="speakText(this.dataset.text, 'en-US')" data-text="<?= $word['sentence'] ?>" class="btn p-0 border-0">
                                            <i class="fa-solid fa-circle-play"></i>
                                        </button>
                                    </td>
                                    <td class="text-center">
                                        <button onclick="speakText(this.dataset.text, 'ja-JP')" data-text="<?= $word['sentence'] ?>" class="btn p-0 border-0">
                                            <i class="fa-solid fa-circle-play"></i>
                                        </button>
                                    </td>

                                    <!-- Dictionary Search Button -->
                                    <td class="text-center">
                                        <a href="<?= getOLDUrl($word['word']) ?>" target="_blank">
                                            <i class="fa-solid fa-book"></i>
                                        </a>
                                    </td>

                                    <!-- Img Search Button -->
                                    <td class="text-center">
                                        <a href="<?= getImageSearchUrl($word['word']) ?>" target="_blank" class="text-success">
                                            <i class="fa-solid fa-image"></i>
                                        </a>
                                    </td>

                                    <!-- Video Search Button -->
                                    <td class="text-center">
                                        <a href="<?= getYouGlishUrl($word['word']) ?>" target="_blank" class="text-danger">
                                            <i class="fa-solid fa-video"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <script src="js/tts.js"></script>
</body>

</html>